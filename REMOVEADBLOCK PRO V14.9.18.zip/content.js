// ==UserScript==
// @name         Jungle Diamond 14.9.16 - Adaptive Stealth Architecture Ultra
// @namespace    https://github.com/
// @version      14.9.18
// @description  Hệ thống cải tiến tối hậu: Giữ nguyên 100% cấu trúc gốc 14.9.5 mượt mà, đắp thêm lớp khiên chống bóp băng thông 2026 và đồng bộ hóa phiên.
// @author       Thai Thong + VN + Gemini
// @match        *://www.youtube.com/*
// @match        *://m.youtube.com/*
// @match        *://music.youtube.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==
// ==================== HỖ TRỢ ĐA NGÔN NGỮ THÔNG MINH (ƯU TIÊN TIẾNG VIỆT) ====================
const LANG_MAP = {
    'vi': "Hệ thống đang tăng tốc bỏ qua quảng cáo...",
    'vn': "Hệ thống đang tăng tốc bỏ qua quảng cáo...",   // Thêm biến thể
    'en': "System accelerating, skipping ads...",
    'de': "System beschleunigt, überspringe Werbung...",
    'fr': "Système en accélération, passage des publicités...",
    'es': "Sistema acelerando, saltando anuncios...",
    'zh': "系统正在加速，跳过广告...",
    'bo': "འཕྲུལ་འཁོར་མགྱོགས་སུ་གཏོང་བཞིན་པ། བརྡ་ཁྱབ་བརྒལ་བཞིན་པ།",
    'th': "ระบบกำลังเร่งความเร็ว ข้ามโฆษณา...",
    'ms': "Sistem memecut, melangkau iklan...",
    'id': "Sistem mempercepat, melewati iklan...",
    'lo': "ລະບົບກຳລັງເລັ່ງ, ข้ามໂຄສະນາ...",
    'km': "ប្រព័ន្ធកំពុងបង្កើនល្បឿន ដោយរំលងការផ្សាយពាណិជ្ជកម្ម...",
    'hi': "सिस्टम तेज हो रहा है, विज्ञापन छोड़े जा रहे हैं...",
    'ja': "システムを加速中、広告をスキップしています...",
    'ko': "시스템 가속 중, 광고 스킵 중...",
    'it': "Sistema in accelerazione, salto pubblicità..."
};

// Nhận diện ngôn ngữ siêu chắc chắn
const USER_LOCALE_TEXT = (() => {
    try {
        // Ưu tiên nhiều nguồn để tránh sai
        let lang = (navigator.language || navigator.userLanguage || navigator.browserLanguage || 'en').toLowerCase();

        // Xử lý cả vi-VN, vi-vn, vi, VN...
        if (lang.includes('vi') || lang.includes('vn')) {
            return LANG_MAP['vi'];
        }

        const shortLang = lang.split('-')[0].trim();
        
        return LANG_MAP[shortLang] || LANG_MAP['en'];
    } catch (e) {
        console.log("[Jungle Shield] Language detection fallback to English");
        return LANG_MAP['en'];
    }
})();


(function() {
    'use strict';
       // ==================== GIẢ LẬP THIẾT BỊ TV MẠNH (4K/8K) ====================
try {
    const HIGH_QUALITY_TV_UA = "Mozilla/5.0 (Linux; Android 14; SHIELD Android TV Build/RTT1.210722.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";
    
    Object.defineProperty(navigator, 'userAgent', { 
        get: () => HIGH_QUALITY_TV_UA, 
        configurable: true 
    });
    Object.defineProperty(navigator, 'appVersion', { 
        get: () => HIGH_QUALITY_TV_UA, 
        configurable: true 
    });
    Object.defineProperty(navigator, 'platform', { 
        get: () => 'Android', 
        configurable: true 
    });
} catch (e) {}
    // ==================== KHỞI TẠO BIẾN TOÀN CỤC & SEED PHIÊN NHẤT QUÁN ====================
    if (!sessionStorage.getItem('JD_SESSION_SEED')) {
        sessionStorage.setItem('JD_SESSION_SEED', Math.random().toString());
    }
    const SESSION_SEED = parseFloat(sessionStorage.getItem('JD_SESSION_SEED'));
    
    const GPU_POOL = [
        { renderer: "ANGLE (Apple, Apple M1, OpenGL 4.1)", vendor: "Apple Inc." },
        { renderer: "ANGLE (Apple, Apple M2, OpenGL 4.1)", vendor: "Apple Inc." },
        { renderer: "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics, OpenGL 4.1)", vendor: "Intel Inc." },
        { renderer: "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060/PCIe/SSE2, OpenGL 4.5)", vendor: "NVIDIA Corporation" }
    ];
    const SELECTED_GPU = GPU_POOL[Math.floor(SESSION_SEED * GPU_POOL.length)];
    const PERSISTENT_CPU_OFFSET = SESSION_SEED > 0.66 ? 2 : (SESSION_SEED > 0.33 ? -2 : 0);
    const PERSISTENT_RAM_SPOOF = SESSION_SEED > 0.5 ? 8 : 16;

    let isUserReadingComments = false;
    let lastStallCheckTime = Date.now();
    let lastVideoPosition = 0;
    let currentCommentObserver = null;
	// ==================== BIẾN MÀN CHE LOGO CSS THÔNG MINH ====================
    let logoShieldDiv = null;
    let shieldResizeObserver = null;
	let isShieldPreCreated = false;   // Cờ kiểm soát đã tạo shield lần đầu chưa

    // ==================== CÁC BIẾN KHỞI TẠO GỐC (GIỮ NGUYÊN BẢO TOÀN) ====================
    let lastPhysicalInteraction = 0;
    let isUserIntentionallyPaused = false;
    const INTERACTION_WINDOW = 2000;

    // Biến kiểm soát chu kỳ dọn dẹp tài nguyên thông minh
    let lastStorageCleanTime = 0;
    let lastBiometricTime = 0;

    // ==================== ANTI-BANNER & ENFORCEMENT CSS ====================
    const injectCSS = () => {
    const css = `
        /* --- 1. CHẶN KHUNG QUẢNG CÁO TRANG CHỦ (TỰ ĐỘNG DỒN GRID, KHÔNG TRỐNG) --- */
        ytd-rich-item-renderer:has(ytd-ad-slot-renderer, ytm-promoted-sparkles-web-renderer, ad-slot-renderer, [class*="ad-slot"]) {
            display: none !important;
        }

        /* --- 2. CHẶN THẺ QUẢNG CÁO ĐƠN LẺ & TĨNH --- */
        square-image-layout-view-model, ad-image-view-model,
        feed-ad-metadata-view-model, ad-button-view-model,
        ytd-ad-slot-renderer, ytm-promoted-sparkles-web-renderer,
        ad-slot-renderer,
        
        /* --- CHẶN QUẢNG CÁO TV / LEANBACK --- */
        ytlr-ad-slot-renderer,
        ytlr-ad-avatar-lockup-renderer,
        ytlr-ad-hover-text-button-renderer,
        ytlr-ad-skip-or-preview,
        
        /* --- OVERLAY & BANNER YOUTUBE WEB & MOBILE --- */
        .ytwSquareImageLayoutViewModelHost, .ytp-ad-module, .ytp-ad-overlay-container,
        #player-ads, ytd-enforcement-message-view-model,
        tp-yt-paper-dialog:has(ytd-enforcement-message-view-model),
        .yt-playability-error-supported-renderers,
        ytd-engagement-panel-title-header-renderer > #banner,
        #ads-info-button.style-scope.ytd-engagement-panel-title-header-renderer,
        ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"],
        ytd-engagement-panel-section-list-renderer:has(panel-ad-header-image-lockup-view-model),
        panel-ad-header-image-lockup-view-model,
        ad-avatar-lockup-view-model,
        ad-image-view-model.ytwAdImageViewModelHostIsClickableAdComponent,
        
        /* --- CHẶN FULL YOUTUBE MUSIC & PROMO POPUP --- */
        ytmusic-mealbar-promo-renderer,
        .ytmusic-popup-container,
        ytmusic-guide-entry-renderer:has([aria-label*="Upgrade"]),
        ytmusic-app-layout ytmusic-mealbar-promo-renderer {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
            height: 0 !important;
            width: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            pointer-events: none !important;
        }
    `;
    let style = document.getElementById('jungle-main-css');
    if (!style) {
        style = document.createElement('style');
        style.id = 'jungle-main-css';
        (document.head || document.documentElement).appendChild(style);
    }
    style.textContent = css;
};

injectCSS();
window.addEventListener('load', injectCSS, { once: true });

// Dùng MutationObserver để theo dõi ngầm, không tốn tài nguyên quét liên tục
const observer = new MutationObserver((mutations) => {
    const dismissBtns = document.querySelectorAll('ytmusic-mealbar-promo-renderer yt-button-renderer.dismiss-button button, ytmusic-mealbar-promo-renderer [dialog-dismiss]');
    dismissBtns.forEach(btn => {
        if (btn) {
            btn.click();
            const mealbar = btn.closest('ytmusic-mealbar-promo-renderer');
            if (mealbar) mealbar.remove();
        }
    });
});

// SỬA LỖI Ở ĐÂY: Kiểm tra nếu document.body chưa có thì chờ DOMContentLoaded mới observe
const startObserving = () => {
    const target = document.body || document.documentElement;
    if (target) {
        observer.observe(target, {
            childList: true,
            subtree: true
        });
    }
};

if (document.body || document.documentElement) {
    startObserving();
} else {
    document.addEventListener('DOMContentLoaded', startObserving, { once: true });
}

    // ==================== GIÁM SÁT THAO TÁC PHẦN CỨNG BẢO VỆ STREAM ====================
    const registerHardwareTracker = () => {
      window.addEventListener('click', (e) => {
        if (e.isTrusted) {
          lastPhysicalInteraction = Date.now();
          const path = e.composedPath();
          const isPlayerAction = path.some(el => {
            if (!el || !el.classList) return false;
            return el.id === 'movie_player' || el.id === 'video-id' ||
              (typeof el.className === 'string' && (
                el.className.includes('ytp-play-button') || el.className.includes('html5-video-container')
              ));
          });
          if (isPlayerAction) {
            const video = document.querySelector('.html5-main-video');
            if (video) isUserIntentionallyPaused = !video.paused;
          }
        }
      }, true);

      window.addEventListener('keydown', (e) => {
        if (e.isTrusted && (e.keyCode === 32 || e.key === ' ' || e.key === 'k' || e.key === 'K')) {
          lastPhysicalInteraction = Date.now();
          const video = document.querySelector('.html5-main-video');
          if (video) isUserIntentionallyPaused = !video.paused;
        }
      }, true);
    };
    registerHardwareTracker();

    // ==================== FINGERPRINT SHIELD NHẤT QUÁN THEO PHIÊN ====================
    const advancedShieldFingerprinting = () => {
        try {
            const originalHardwareConcurrency = navigator.hardwareConcurrency;
            Object.defineProperty(navigator, 'hardwareConcurrency', {
                get: () => originalHardwareConcurrency > 2 ? originalHardwareConcurrency + PERSISTENT_CPU_OFFSET : originalHardwareConcurrency
            });
            if (navigator.deviceMemory) {
                Object.defineProperty(navigator, 'deviceMemory', { get: () => PERSISTENT_RAM_SPOOF });
            }
            const nativeGetChannelData = AudioBuffer.prototype.getChannelData;
            AudioBuffer.prototype.getChannelData = function() {
                const buffer = nativeGetChannelData.apply(this, arguments);
                if (buffer && buffer.length > 0) {
                    buffer[0] += (SESSION_SEED - 0.5) * 1e-7;
                }
                return buffer;
            };
            const maskWebGL = (ctx) => {
                if (!ctx) return;
                const nativeGetParameter = ctx.prototype.getParameter;
                ctx.prototype.getParameter = function(p) {
                    if (p === 35660) return SELECTED_GPU.renderer;
                    if (p === 35661) return SELECTED_GPU.vendor;
                    return nativeGetParameter.apply(this, arguments);
                };
            };
            if (window.WebGLRenderingContext) maskWebGL(WebGLRenderingContext);
            if (window.WebGL2RenderingContext) maskWebGL(WebGL2RenderingContext);

            const nativeGetImageData = CanvasRenderingContext2D.prototype.getImageData;
            CanvasRenderingContext2D.prototype.getImageData = function() {
                const res = nativeGetImageData.apply(this, arguments);
                if (res && res.data && res.data.length > 0) {
                    res.data[0] = res.data[0] ^ (SESSION_SEED > 0.5 ? 1 : 0);
                }
                return res;
            };

            const defineIfConfigurable = (obj, prop, descriptor) => {
                const desc = Object.getOwnPropertyDescriptor(obj, prop);
                if (!desc || desc.configurable) {
                    Object.defineProperty(obj, prop, descriptor);
                }
            };

            defineIfConfigurable(navigator, 'webdriver', { get: () => false, configurable: true });
            defineIfConfigurable(navigator, 'languages', { get: () => ['en-US', 'en'], configurable: true });
            defineIfConfigurable(navigator, 'plugins', {
                get: () => [{ name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format' }],
                configurable: true
            });
            defineIfConfigurable(navigator, 'mimeTypes', {
                get: () => [{ type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format' }],
                configurable: true
            });

            if (navigator.permissions && navigator.permissions.query) {
                const nativePermissionsQuery = navigator.permissions.query.bind(navigator.permissions);
                navigator.permissions.query = (parameters) => {
                    if (parameters && parameters.name === 'notifications') {
                        return Promise.resolve({ state: Notification.permission });
                    }
                    return nativePermissionsQuery(parameters);
                };
            }
        } catch (e) {}
    };
    advancedShieldFingerprinting();

    // ==================== THAO TÚNG DỮ LIỆU BÓC LỘT SÂU TÀNG HÌNH ====================
    const manipulatePlayerResponse = (obj) => {
      if (!obj) return;

      if (obj.playabilityStatus) {
        if (obj.playabilityStatus.status === "UNPLAYABLE" || obj.playabilityStatus.errorScreen || obj.playabilityStatus.status === "LOGIN_REQUIRED" || obj.playabilityStatus.messages) {
          obj.playabilityStatus.status = "OK";
          delete obj.playabilityStatus.errorScreen;
          delete obj.playabilityStatus.messages;

          if (!obj.playabilityStatus.playableInEmbed) {
            obj.playabilityStatus.playableInEmbed = true;
          }
          console.log("[Jungle Proxy] Ép trạng thái luồng gốc & Bỏ lỗi màn hình đen thành công!");
        }
      }

      if (obj.adPlacements) obj.adPlacements = [];
      if (obj.playerAds) delete obj.playerAds;
      if (obj.playerConfig) delete obj.playerConfig;

      if (obj.streamingData && obj.streamingData.adaptiveFormats) {
        obj.streamingData.adaptiveFormats = obj.streamingData.adaptiveFormats.filter(fmt => !fmt.signatureCipher);
      }

      if (obj.auxiliaryUi && obj.auxiliaryUi.messageRenderers && obj.auxiliaryUi.messageRenderers.enforcementMessageViewModel) {
        delete obj.auxiliaryUi.messageRenderers.enforcementMessageViewModel;
        console.log("[Jungle Proxy] Đã triệt tiêu tận gốc auxiliary Enforcement JSON!");
      }

      if (obj.adBreakServiceConfig) delete obj.adBreakServiceConfig;

      if (obj.playerResponse) manipulatePlayerResponse(obj.playerResponse);
    };

    try {
    const nativeParse = JSON.parse;
    JSON.parse = function(text, reviver) {
        const res = nativeParse.apply(this, arguments);
        if (res && typeof res === 'object') {
            // Kiểm tra nhanh: Chỉ xử lý nếu JSON thực sự chứa các key quảng cáo/playability
            const isTarget = res.playabilityStatus || res.adPlacements || res.playerAds || res.playerResponse || res.auxiliaryUi;
            if (isTarget) {
                manipulatePlayerResponse(res);
            }
        }
        return res;
    };
} catch (e) {}

    // ==================== PROXY YTPLAYER GLOBAL CONFIG ====================
    const proxyPlayerConfig = () => {
      if (window.ytplayer && window.ytplayer.config) {
        let currentConfig = window.ytplayer.config;
        window.ytplayer.config = new Proxy(currentConfig, {
          set: function(target, prop, value) {
            if (prop === 'args' || prop === 'playerResponse') {
              if (value && typeof value === 'object') {
                manipulatePlayerResponse(value);
              } else if (value && typeof value === 'string') {
                try {
                  let parsed = JSON.parse(value);
                  manipulatePlayerResponse(parsed);
                  value = JSON.stringify(parsed);
                } catch (e) {}
              }
            }
            target[prop] = value;
            return true;
          }
        });
        if (window.ytplayer.config.args) manipulatePlayerResponse(window.ytplayer.config.args);
        if (window.ytplayer.config.playerResponse) manipulatePlayerResponse(window.ytplayer.config.playerResponse);
      }
    };
    const configInterval = setInterval(() => {
      if (window.ytplayer) {
        proxyPlayerConfig();
        clearInterval(configInterval);
      }
    }, 10);
    setTimeout(() => clearInterval(configInterval), 5000);

    // ==================== ĐÁNH CHẶN YTCFG CHỐNG HONEY BADGER QUÉT NGẦM ====================
    const interceptYtcfg = () => {
        const sanitizeConfig = (obj) => {
            if (obj && typeof obj === 'object') {
                if (obj.EXPERIMENTS_FOR_HONEY_BADGER) obj.EXPERIMENTS_FOR_HONEY_BADGER = [];
                if (obj.FeaturesUnderDeploy && obj.FeaturesUnderDeploy.control_flow_enforcement) obj.FeaturesUnderDeploy.control_flow_enforcement = false;
                if (obj.wv_control_flow_enforcement_enabled) obj.wv_control_flow_enforcement_enabled = false;
                if (obj.disable_adblock_detection === false) obj.disable_adblock_detection = true;
            }
        };
        if (window.ytcfg && window.ytcfg.set && !window.ytcfg.set.isProxied) {
            const nativeSet = window.ytcfg.set;
            window.ytcfg.set = function(first) {
                if (first && typeof first === 'object') sanitizeConfig(first);
                return nativeSet.apply(this, arguments);
            };
            window.ytcfg.set.isProxied = true;
            if (window.ytcfg.data_) sanitizeConfig(window.ytcfg.data_);
        }
    };
    interceptYtcfg();

    // ==================== STEALTH REPORTING INTERCEPTOR (OPTIMIZED) ====================

// 1. Chỉ lọc các endpoint tracking/quảng cáo thực sự (Đã loại bỏ: innertube, playback, ytcfg, signal)
const TRACKING_KEYWORDS = /ptracking|ad_status|conversion|bat\.bing|pagead|virtualadview|doubleclick|googlesyndication|google-analytics|analytics|player_204|ad_impression|log_event|youtubei\/v1\/ad|youtubei\/v1\/attest|ad_break|report_ad|partnerwide|enforcement|adblock|instream/;

const shouldBlockTrackingRequest = (url) => {
    if (!url) return false;
    try {
        const urlString = (typeof url === 'string' ? url : url.url || url.toString()).toLowerCase();
        return TRACKING_KEYWORDS.test(urlString);
    } catch (e) {
        return false;
    }
};

// 2. Chặn navigator.sendBeacon
const nativeSendBeacon = navigator.sendBeacon ? navigator.sendBeacon.bind(navigator) : null;
if (nativeSendBeacon) {
    navigator.sendBeacon = function(url, data) {
        if (shouldBlockTrackingRequest(url)) {
            return true; // Giả lập đã gửi thành công
        }
        return nativeSendBeacon(url, data);
    };
}

// 3. Chặn XMLHttpRequest
const nativeOpen = XMLHttpRequest.prototype.open;
const nativeSend = XMLHttpRequest.prototype.send;

XMLHttpRequest.prototype.open = function(method, url) {
    // Chỉ đánh dấu request này có thuộc diện bị chặn hay không
    this.__isBlockedTracking = shouldBlockTrackingRequest(url);
    return nativeOpen.apply(this, arguments);
};

XMLHttpRequest.prototype.send = function(body) {
    if (this.__isBlockedTracking) {
        // Giả lập phản hồi thành công (200 OK) tại bước send()
        Object.defineProperties(this, {
            status: { value: 200, writable: false },
            statusText: { value: 'OK', writable: false },
            readyState: { value: 4, writable: false },
            responseText: { value: '{}', writable: false },
            response: { value: '{}', writable: false }
        });

        setTimeout(() => {
            if (typeof this.onreadystatechange === 'function') this.onreadystatechange();
            if (typeof this.onload === 'function') this.onload();
        }, 1);

        return; // Dừng không cho gửi request thật
    }
    return nativeSend.apply(this, arguments);
};

// 4. Chặn window.fetch
const nativeFetch = window.fetch.bind(window);
window.fetch = async function(input, init) {
    let url = '';
    if (typeof input === 'string') {
        url = input;
    } else if (input instanceof Request || (input && input.url)) {
        url = input.url;
    } else if (input && typeof input.toString === 'function') {
        url = input.toString();
    }

    if (shouldBlockTrackingRequest(url)) {
        // Bắt chước response JSON rỗng chuẩn 200 OK
        return new Response('{}', {
            status: 200,
            statusText: 'OK',
            headers: { 'Content-Type': 'application/json' }
        });
    }
    return nativeFetch(input, init);
};

    // ==================== MÀN CHE DỪNG HÌNH & DIỆT QUẢNG CÁO TỐI ƯU ====================
    const injectShieldStyles = () => {
        if (document.getElementById('jungle-shield-animation-styles')) return;
        const style = document.createElement('style');
        style.id = 'jungle-shield-animation-styles';
        style.textContent = `
            @keyframes pulse-glow-red {
                0%, 100% { box-shadow: 0 0 15px rgba(255, 23, 68, 0.35); transform: scale(0.97); }
                50% { box-shadow: 0 0 40px rgba(255, 23, 68, 0.8); transform: scale(1.03); }
            }
            @keyframes pulse-green {
                0%, 100% { transform: scale(0.9); box-shadow: 0 0 4px #00e676; opacity: 0.7; }
                50% { transform: scale(1.2); box-shadow: 0 0 12px #00e676; opacity: 1; }
            }
        `;
        (document.head || document.documentElement).appendChild(style);
    };

    const preCreateLogoShield = () => {
    injectShieldStyles();
    const player = document.getElementById('movie_player') || 
                   document.querySelector('.html5-video-player') || 
                   document.querySelector('#player-container');
    if (!player) return false;

    // Nếu Khiên đã tồn tại VÀ vẫn còn thực sự nằm trên giao diện -> Không cần tạo lại
    if (logoShieldDiv && document.body.contains(logoShieldDiv)) {
        return true;
    }

    // Nếu Khiên cũ đã bị gỡ khỏi DOM, dọn dẹp để tạo mới
    if (logoShieldDiv) {
        try { logoShieldDiv.remove(); } catch(e) {}
        logoShieldDiv = null;
    }

    logoShieldDiv = document.createElement('div');
    logoShieldDiv.id = "jungle-logo-shield";
    
    // NÂNG CẤP BẮT BỘC: Phủ đen tuyệt đối 100% (#000000 !important) + Backdrop Blur chặn hoàn toàn bóng video
    logoShieldDiv.style.cssText = `
        position: absolute !important; top: 0 !important; left: 0 !important;
        width: 100% !important; height: 100% !important;
        background: #000000 !important;
        background-color: #000000 !important;
        backdrop-filter: blur(25px) !important;
        -webkit-backdrop-filter: blur(25px) !important;
        display: flex !important; flex-direction: column !important; align-items: center !important; justify-content: center !important;
        z-index: 2147483647 !important; opacity: 0; pointer-events: none;
        transition: opacity 0.2s cubic-bezier(0.4, 0, 0.2, 1); visibility: hidden;
        font-family: "Roboto", "YouTube Sans", Arial, sans-serif;
        user-select: none; box-sizing: border-box; padding: 20px;
    `;

    const centerContainer = document.createElement('div');
    centerContainer.style.cssText = `
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        transform: scale(min(1, var(--shield-scale, 1))); transition: transform 0.2s ease-out;
    `;

    const playButton = document.createElement('div');
    playButton.style.cssText = `
        width: clamp(70px, 10vw, 100px); height: clamp(70px, 10vw, 100px);
        background: rgba(244, 67, 54, 0.1); border: 2px solid #ff1744;
        border-radius: 50%; display: flex; align-items: center; justify-content: center;
        box-shadow: 0 0 30px rgba(255, 23, 68, 0.4);
        animation: pulse-glow-red 2s infinite ease-in-out;
    `;

    const playTriangle = document.createElement('div');
    playTriangle.style.cssText = `
        width: 0; height: 0;
        border-top: clamp(14px, 2vw, 20px) solid transparent;
        border-bottom: clamp(14px, 2vw, 20px) solid transparent;
        border-left: clamp(24px, 3.5vw, 32px) solid #ff1744;
        margin-left: clamp(5px, 0.8vw, 8px);
    `;
    playButton.appendChild(playTriangle);

    const titleText = document.createElement('div');
    titleText.textContent = "YT PREMIUM ULTRA";
    titleText.style.cssText = `
        color: #ffffff; font-size: clamp(16px, 2.5vw, 24px); font-weight: 900;
        letter-spacing: 4px; margin-top: 24px; text-shadow: 0 2px 10px rgba(0,0,0,0.8);
    `;

    const statusContainer = document.createElement('div');
    statusContainer.style.cssText = `margin-top: 16px; display: flex; align-items: center; gap: 8px;`;

    const pulseDot = document.createElement('div');
    pulseDot.style.cssText = `
        width: 8px; height: 8px; background-color: #00e676; border-radius: 50%;
        box-shadow: 0 0 8px #00e676; animation: pulse-green 1.5s infinite;
    `;

    const statusText = document.createElement('div');
    statusText.textContent = typeof USER_LOCALE_TEXT !== 'undefined' ? USER_LOCALE_TEXT : "Protected";
    statusText.style.cssText = `
        color: rgba(255, 255, 255, 0.7); font-size: clamp(11px, 1.5vw, 13px); font-weight: 500;
    `;

    statusContainer.appendChild(pulseDot);
    statusContainer.appendChild(statusText);
    centerContainer.appendChild(playButton);
    centerContainer.appendChild(titleText);
    centerContainer.appendChild(statusContainer);

    const footerText = document.createElement('div');
    footerText.textContent = "Developer: ThaiThongSj@gmail.com";
    footerText.style.cssText = `
        position: absolute; bottom: clamp(15px, 4vw, 30px);
        color: rgba(255, 255, 255, 0.35); font-size: clamp(9px, 1.2vw, 11px);
    `;

    logoShieldDiv.appendChild(centerContainer);
    logoShieldDiv.appendChild(footerText);
    player.appendChild(logoShieldDiv);

    if (shieldResizeObserver) shieldResizeObserver.disconnect();
    shieldResizeObserver = new ResizeObserver(entries => {
        for (let entry of entries) {
            const width = entry.contentRect.width;
            const scale = width < 400 ? 0.75 : (width < 600 ? 0.85 : 1);
            if (logoShieldDiv) logoShieldDiv.style.setProperty('--shield-scale', scale);
        }
    });
    shieldResizeObserver.observe(player);

    isShieldPreCreated = true;
    return true;
};

    const toggleLogoShield = (show) => {
    // TỰ PHỤC HỒI: Tạo lại ngay nếu khiên bị gỡ khỏi DOM
    if (!logoShieldDiv || !document.body.contains(logoShieldDiv)) {
        isShieldPreCreated = false;
        const created = preCreateLogoShield();
        if (!created || !logoShieldDiv) return;
    }

    if (show) {
        logoShieldDiv.style.visibility = "visible";
        logoShieldDiv.style.opacity = "1";
        logoShieldDiv.style.pointerEvents = "auto";
    } else {
        logoShieldDiv.style.opacity = "0";
        logoShieldDiv.style.pointerEvents = "none";
        setTimeout(() => {
            if (logoShieldDiv && logoShieldDiv.style.opacity === "0") {
                logoShieldDiv.style.visibility = "hidden";
            }
        }, 200);
    }
};
const executeVirtualAcceleration = (video) => {
    if (!video) return;

    // 1. Chỉ kiểm tra Quảng cáo ĐANG PHÁT TRONG VIDEO (Loại bỏ hoàn toàn thẻ tĩnh/banner)
    const player = document.getElementById('movie_player') || 
                   document.querySelector('.html5-video-player') || 
                   document.querySelector('ytlr-player');

    const isAdShowing = (player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'))) ||
        !!document.querySelector('.ytp-ad-player-overlay, .ytp-ad-showing, ytlr-skip-ad-renderer, .ytp-ad-skip-button-container, ytlr-ad-skip-or-preview');

    // Nếu KHÔNG PHẢI quảng cáo video đang phát -> Tắt khiên, khôi phục tốc độ gốc và THOÁT NGAY
    if (!isAdShowing) {
        toggleLogoShield(false);
        if (video.playbackRate > 2) {
            video.playbackRate = 1; // Khôi phục tốc độ chuẩn cho video chính
        }
        return;
    }

    // === CHỈ KHI ĐANG CÓ QUẢNG CÁO VIDEO THẬT SỰ ===
    if (!isShieldPreCreated) preCreateLogoShield();
    toggleLogoShield(true);

    // Mute tiếng quảng cáo
    if (!video.muted) video.muted = true;
    video.volume = 0;

    // Tua gia tốc / Bỏ qua quảng cáo
    if (isFinite(video.duration) && video.duration > 0) {
        video.currentTime = video.duration;
    } else {
        video.playbackRate = 16;
    }

    // Bấm nút Skip quảng cáo (cả Web lẫn YouTube TV)
    document.querySelectorAll(
        '.ytp-ad-skip-button, .ytp-skip-ad-button, .ytp-ad-skip-button-modern, ' +
        'button[aria-label*="Skip"], button[aria-label*="Bỏ qua"], ' +
        'ytlr-button[idomkey="skip-button"], [idomkey="skip-button"], .ytlr-ad-skip-button'
    ).forEach(btn => {
        btn.click();
        btn.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    });
};

    // CLEANER STORAGE (ĐIỀU TỐC THÔNG MINH - THỜI GIAN THROTTLE NỚI RỘNG LÊN 25 GIÂY)
    const cleanEnforcementStorage = () => {
      const now = Date.now();
      // ĐIỂM 3: Tăng chu kỳ dọn dẹp bộ nhớ lên 25 giây để giảm tải hoàn toàn nghẽn I/O main-thread
      if (now - lastStorageCleanTime < 25000) return;
      lastStorageCleanTime = now;

      try {
        const len = localStorage.length;
        for (let i = len - 1; i >= 0; i--) {
          const key = localStorage.key(i);
          if (key && (key.includes('yt-player-enforcement') || key.includes('adblock') || key.includes('yt-ad'))) {
            localStorage.removeItem(key);
          }
        }
      } catch (e) {}
    };

    let lastDomCleanTime = 0;
const cleanEnforcementDOM = () => {
        const now = Date.now();
        if (now - lastDomCleanTime < 1500) return;
        lastDomCleanTime = now;

        const selectors = [
            'ytd-rich-item-renderer:has(ytd-ad-slot-renderer, ad-slot-renderer)',
            'ytd-ad-slot-renderer', 'ytlr-ad-slot-renderer',
            'ytlr-ad-avatar-lockup-renderer', 'ytlr-ad-hover-text-button-renderer',
            'ytlr-ad-skip-or-preview', 'ytd-promoted-video-renderer',
            '.ytp-ad-module', '.video-ads', '#player-ads',
            '.ytp-ad-overlay-container', 'tp-yt-iron-overlay-backdrop',
            'tp-yt-paper-dialog:has(ytd-enforcement-message-view-model)',
            'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]',
            'ytd-enforcement-message-view-model', '.ytp-ad-text-overlay',
            '.ytp-ad-preview-container', 'ytmusic-mealbar-promo-renderer'
        ];
        
        for (let i = 0; i < selectors.length; i++) {
            const els = document.querySelectorAll(selectors[i]);
            for (let j = 0; j < els.length; j++) {
                els[j].remove();
            }
        }
    };

    // ==================== CƠ CHẾ DỰ PHÒNG: TỰ KHÔI PHỤC KHI BỊ CHẶN CỨNG ====================
    const forceEmergencyRecovery = (video) => {
      console.log("[Jungle Diamond Fallback] Kích hoạt cơ chế hồi sinh stream khẩn cấp!");
      lastStorageCleanTime = 0;
      cleanEnforcementStorage();

      const player = document.getElementById('movie_player');
      if (player && typeof player.loadVideoById === 'function') {
        const urlParams = new URLSearchParams(window.location.search);
        const videoId = urlParams.get('v');
        if (videoId) {
          let currentTime = video.currentTime || 0;
          player.loadVideoById(videoId, currentTime);
        }
      }
    };

    // ==================== ĐỘNG CƠ TỰ CHỮA LÀNH LUỒNG TẢI TRÁNH BỊ BÓP BĂNG THÔNG ====================
    const runSelfHealingCore = (video) => {
        if (!video || isUserIntentionallyPaused || document.querySelector('.ad-showing, .ad-interrupting')) return;
        const now = Date.now();
        if (video.playbackRate > 0 && video.playbackRate < 1) {
            video.playbackRate = 1;
        }
        if (!video.paused) {
            if (video.currentTime === lastVideoPosition) {
                if (now - lastStallCheckTime > 2500) { 
                    lastStorageCleanTime = 0; 
                    cleanEnforcementStorage();
                    video.currentTime += 0.1; 
                    video.play().catch(() => {});
                    lastStallCheckTime = now;
                }
            } else {
                lastVideoPosition = video.currentTime;
                lastStallCheckTime = now;
            }
        }
    };

    // ==================== BIOMETRIC ENTROPY (ĐIỂM 1: CHUYỂN SANG REQUESTIDLECALLBACK TRÁNH MICRO-STUTTERING) ====================
    const runBiometricEntropy = (video) => {
        if (document.hidden || (Date.now() - lastPhysicalInteraction < 5000)) return;
        
        const player = document.getElementById('movie_player');
        if (player && video && !video.paused && !document.querySelector('.ad-showing, .ad-interrupting')) {
            if (isUserReadingComments) {
                window.scrollBy({ top: SESSION_SEED > 0.5 ? 1 : -1, behavior: 'smooth' });
            }
            const rect = player.getBoundingClientRect();
            player.dispatchEvent(new MouseEvent('mousemove', {
                clientX: rect.left + (rect.width * (0.25 + SESSION_SEED * 0.5)),
                clientY: rect.top + (rect.height * (0.25 + SESSION_SEED * 0.5)),
                bubbles: true
            }));
        }
    };

    // ==================== ENGINE 3: NONSTOP ĐỒNG BỘ - ĐIỀU PHỐI THÔNG MINH ====================
    let isHandlingNonstop = false;
    let lastExecutionTime = 0;

    window.nonstopHandler = function() {
      const now = Date.now();
      if (isHandlingNonstop || (now - lastExecutionTime < 100)) return;
      isHandlingNonstop = true;
      lastExecutionTime = now;

      try {
        const video = document.querySelector('.html5-main-video');
        if (!video) return;

        if (isUserIntentionallyPaused || (Date.now() - lastPhysicalInteraction < INTERACTION_WINDOW)) {
          return;
        }

        let needForcePlay = false;

        const dialogs = document.querySelectorAll('yt-confirm-dialog-renderer, tp-yt-paper-dialog, ytd-enforcement-message-view-model, .yt-playability-error-supported-renderers');
        dialogs.forEach(dialog => {
          if (dialog.style.display === 'none') return;
          const text = (dialog.textContent || '').toLowerCase();
          if (/video paused|continue watching|tạm dừng|tiếp tục|still watching|ad block|quảng cáo|vi phạm/.test(text)) {

            dialog.remove();
            needForcePlay = true;

            if (text.includes('ad block') || text.includes('quảng cáo') || text.includes('vi phạm')) {
              forceEmergencyRecovery(video);
            }
          }
        });

        const backdrops = document.querySelectorAll('tp-yt-iron-overlay-backdrop');
        if (backdrops.length > 0) {
          backdrops.forEach(el => el.remove());
          needForcePlay = true;
        }

        if (video.paused && (needForcePlay || !isUserIntentionallyPaused)) {
          const player = document.getElementById('movie_player');
          if (player && typeof player.playVideo === 'function') {
            player.playVideo();
          }

          const playPromise = video.play();
          if (playPromise !== undefined) {
            playPromise.catch(() => {
              const playBtn = document.querySelector('.ytp-play-button');
              if (playBtn) playBtn.click();
            });
          }
        }
      } catch (e) {
                // console.log('[Jungle Diamond Nonstop Error]: ', e); // Tắt để tránh spam
      } finally {
        isHandlingNonstop = false;
      }
    };

    // ==================== ĐIỂM 2: VÒNG LẶP CORE LOOP ĐIỀU PHỐI TRUNG TÂM BIẾN THIÊN THÔNG MINH ====================
    // Triệt tiêu toàn bộ các setInterval độc lập chạy 1s để giảm "CPU Wake-ups", ngăn biến video bị stale
    const startCentralCoreLoop = () => {
    const now = Date.now();
    // Hỗ trợ bắt video linh hoạt hơn cho cả Web và YouTube TV
    const freshVideo = document.querySelector('.html5-main-video') || document.querySelector('video');

    if (freshVideo) {
        // Luôn kiểm tra gia tốc ảo bên trong lõi điều phối
        executeVirtualAcceleration(freshVideo);

        // Khôi phục lại âm thanh cho Video chính sau khi quảng cáo kết thúc
        const player = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
        const isAdShowing = player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'));
        
        if (!isAdShowing && freshVideo.muted && freshVideo.volume === 0 && !isUserIntentionallyPaused) {
            freshVideo.muted = false;
            freshVideo.volume = 1;
        }

        // Kiểm tra bóp tiến trình ngầm định kỳ độc lập
        runSelfHealingCore(freshVideo);

        // Xử lý chống tạm dừng tự động
        if (freshVideo.paused && !isAdShowing && !isUserIntentionallyPaused && (now - lastPhysicalInteraction > INTERACTION_WINDOW)) {
            window.nonstopHandler();
        }
    }

    // Tích hợp dọn dẹp đĩa cứng tập trung (Throttled 25 giây)
    cleanEnforcementStorage();

    // Tích hợp giả lập sinh trắc học thông minh sử dụng requestIdleCallback để chạy khi CPU rảnh rỗi
    if (now - lastBiometricTime >= (4000 + (SESSION_SEED * 3000))) {
        if (typeof requestIdleCallback === 'function') {
            requestIdleCallback(() => {
                runBiometricEntropy(freshVideo);
            });
        } else {
            runBiometricEntropy(freshVideo);
        }
        lastBiometricTime = now;
    }

    cleanEnforcementDOM();

    // Tối ưu hóa chu kỳ đánh thức biến thiên
    let dynamicInterval = 1000;
    if (freshVideo && !freshVideo.paused && freshVideo.currentTime === lastVideoPosition) {
        dynamicInterval = 250; 
    }

    setTimeout(startCentralCoreLoop, dynamicInterval);
};

    // ==================== KHỞI CHẠY HỆ THỐNG GIÁM SÁT REAL-TIME ====================
const initObserver = () => {
    // Tìm Player & Video linh hoạt hỗ trợ cả TV Leanback lẫn Web
    const player = document.getElementById('movie_player') || 
                   document.querySelector('.html5-video-player') || 
                   document.querySelector('ytlr-player') || 
                   document.querySelector('#player-container');
                   
    const video = document.querySelector('.html5-main-video') || document.querySelector('video');
    
    // TẠO SHIELD SỚM NHẤT CÓ THỂ
    if (player) preCreateLogoShield();
    if (!player || !video) {
        setTimeout(initObserver, 150);
        return;
    }

    // Kích hoạt Vòng Lặp Lõi Điều Phối Biến Thiên Trung Tâm (nếu hàm tồn tại)
    if (typeof startCentralCoreLoop === 'function') {
        startCentralCoreLoop();
    }

    // Giám sát MutationObserver thuộc tính khung Player
    new MutationObserver(() => {
        const freshVideo = document.querySelector('.html5-main-video') || document.querySelector('video');
        if (freshVideo) executeVirtualAcceleration(freshVideo);
    }).observe(player, {
        attributes: true,
        attributeFilter: ['class']
    });

    // Lắng nghe sự kiện luồng video chính thống tránh lỗi stale tham chiếu cũ
    ['play', 'ratechange', 'playing'].forEach(evt => {
        video.addEventListener(evt, () => {
            const freshVideo = document.querySelector('.html5-main-video') || document.querySelector('video');
            if (freshVideo) {
                executeVirtualAcceleration(freshVideo);
                if (typeof runSelfHealingCore === 'function') runSelfHealingCore(freshVideo);
            }
        });
    });

    video.addEventListener('pause', () => {
        const timeSinceLastInteraction = Date.now() - lastPhysicalInteraction;
        if (timeSinceLastInteraction > INTERACTION_WINDOW) {
            isUserIntentionallyPaused = false;
            setTimeout(window.nonstopHandler, 150);
        }
    });

    // Chống spam log rác và giảm tải CPU bằng Debounce độc lập (50ms)
    let debounceTimer = null;
    const dialogObserver = new MutationObserver(() => {
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            window.nonstopHandler();
        }, 50);
    });

    const popupContainer = document.querySelector('ytd-popup-container') || 
                           document.querySelector('ytlr-app') || 
                           document.getElementById('content') || 
                           document.body;
                           
    if (popupContainer) {
        dialogObserver.observe(popupContainer, {
            childList: true,
            subtree: false
        });
    }

    // Quét vùng comment bằng IntersectionObserver theo chu trình SPA 
    const setupCommentObserver = () => {
        if (typeof currentCommentObserver !== 'undefined' && currentCommentObserver) {
            currentCommentObserver.disconnect();
        }
        const commentsSection = document.getElementById('comments');
        if (commentsSection) {
            currentCommentObserver = new IntersectionObserver((entries) => {
                isUserReadingComments = entries.some(entry => entry.isIntersecting);
            }, { threshold: 0.01 });
            currentCommentObserver.observe(commentsSection);
        }
    };
    setupCommentObserver();

    // HÀM XỬ LÝ CHUYỂN BÀI CHUNG (Dùng cho cả Web SPA & TV Hash Routing)
    const handleNavigationEvent = () => {
        isUserIntentionallyPaused = false; // Reset cờ cố tình tạm dừng
        lastPhysicalInteraction = 0;       // Xóa lịch sử click thumbnail để bỏ qua khóa 2s
        
        setupCommentObserver();
        lastStorageCleanTime = 0;
        cleanEnforcementStorage();

        // Ép kích hoạt phát video ngay lập tức
        setTimeout(() => {
            const freshVideo = document.querySelector('.html5-main-video') || document.querySelector('video');
            if (freshVideo && freshVideo.paused) {
                window.nonstopHandler();
            }
        }, 150);
    };

    // Lắng nghe sự kiện chuyển trang trên Web
    window.addEventListener('yt-navigate-finish', handleNavigationEvent);

    // BỔ SUNG: Lắng nghe sự kiện chuyển video trên YouTube TV (/tv#/watch)
    window.addEventListener('hashchange', handleNavigationEvent);
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initObserver);
} else {
    initObserver();
}
})();